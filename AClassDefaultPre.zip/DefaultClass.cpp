#include "PrecompileHeader.h"
#include "$safeitemname$.h"

$safeitemname$::$safeitemname$() 
{
}

$safeitemname$::~$safeitemname$() 
{
}

